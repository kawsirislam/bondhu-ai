package com.bondhu.ai.nativebridge

import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.util.Base64
import androidx.core.app.NotificationCompat
import java.io.ByteArrayOutputStream
import kotlin.math.max
import kotlin.math.roundToInt

/**
 * Official Android MediaProjection Foreground Service for User-Authorized Screen Understanding.
 * Strictly Read-Only observation: never saves frames to disk, never captures without explicit
 * system consent, and stops immediately when the user stops Screen Share.
 */
class BondhuScreenCaptureService : Service() {

    companion object {
        const val CHANNEL_ID = "bondhu_screen_share_channel"
        const val NOTIF_ID = 4402
        const val ACTION_START = "com.bondhu.ai.START_SCREEN_CAPTURE"
        const val ACTION_STOP = "com.bondhu.ai.STOP_SCREEN_CAPTURE"
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_RESULT_DATA = "result_data"

        private const val MIN_FRAME_INTERVAL_MS = 1100L
        private const val TARGET_MAX_WIDTH = 540

        @Volatile
        var isCaptureActive: Boolean = false
            private set

        @Volatile
        var frameListener: ((String) -> Unit)? = null

        @Volatile
        var stateListener: ((Boolean, String?) -> Unit)? = null

        fun start(context: Context, resultCode: Int, data: Intent) {
            val intent = Intent(context, BondhuScreenCaptureService::class.java).apply {
                action = ACTION_START
                putExtra(EXTRA_RESULT_CODE, resultCode)
                putExtra(EXTRA_RESULT_DATA, data)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stop(context: Context) {
            val intent = Intent(context, BondhuScreenCaptureService::class.java).apply {
                action = ACTION_STOP
            }
            try {
                context.startService(intent)
            } catch (_: Exception) {
                isCaptureActive = false
                stateListener?.invoke(false, "স্ক্রিন শেয়ার বন্ধ করা হয়েছে।")
            }
        }
    }

    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var captureThread: HandlerThread? = null
    private var captureHandler: Handler? = null
    private val mainHandler = Handler(Looper.getMainLooper())
    private var lastFrameSentAt = 0L

    private val projectionCallback = object : MediaProjection.Callback() {
        override fun onStop() {
            mainHandler.post {
                stopSelfCleanly("সিস্টেম থেকে স্ক্রিন শেয়ার বন্ধ করা হয়েছে।")
            }
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelfCleanly("ব্যবহারকারী স্ক্রিন শেয়ার বন্ধ করেছেন।")
            return START_NOT_STICKY
        }

        val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED) ?: Activity.RESULT_CANCELED
        val resultData: Intent? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            intent?.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent?.getParcelableExtra(EXTRA_RESULT_DATA)
        }

        if (resultCode != Activity.RESULT_OK || resultData == null) {
            stopSelfCleanly("স্ক্রিন শেয়ারের অনুমতি পাওয়া যায়নি।")
            return START_NOT_STICKY
        }

        val notification = buildNotification()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIF_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(NOTIF_ID, notification)
        }

        startProjectionPipeline(resultCode, resultData)
        return START_NOT_STICKY
    }

    private fun startProjectionPipeline(resultCode: Int, resultData: Intent) {
        tearDownProjectionResources()

        val projectionManager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as? MediaProjectionManager
        val projection = projectionManager?.getMediaProjection(resultCode, resultData)
        if (projection == null) {
            stopSelfCleanly("MediaProjection শুরু করা যায়নি।")
            return
        }

        mediaProjection = projection
        projection.registerCallback(projectionCallback, mainHandler)

        val metrics = resources.displayMetrics
        val rawWidth = max(360, metrics.widthPixels)
        val rawHeight = max(640, metrics.heightPixels)
        val scale = if (rawWidth > TARGET_MAX_WIDTH) TARGET_MAX_WIDTH.toFloat() / rawWidth.toFloat() else 1f
        val capWidth = max(240, (rawWidth * scale).roundToInt())
        val capHeight = max(320, (rawHeight * scale).roundToInt())
        val densityDpi = max(120, (metrics.densityDpi * scale).roundToInt())

        val thread = HandlerThread("BondhuScreenCaptureThread").apply { start() }
        captureThread = thread
        val handler = Handler(thread.looper)
        captureHandler = handler

        val reader = ImageReader.newInstance(capWidth, capHeight, PixelFormat.RGBA_8888, 2)
        imageReader = reader
        lastFrameSentAt = 0L

        reader.setOnImageAvailableListener({ r ->
            if (!isCaptureActive) return@setOnImageAvailableListener
            val image = try {
                r.acquireLatestImage()
            } catch (_: Exception) {
                null
            } ?: return@setOnImageAvailableListener

            try {
                val now = System.currentTimeMillis()
                if (now - lastFrameSentAt < MIN_FRAME_INTERVAL_MS) {
                    return@setOnImageAvailableListener
                }
                val plane = image.planes.firstOrNull() ?: return@setOnImageAvailableListener
                val buffer = plane.buffer
                val pixelStride = plane.pixelStride
                val rowStride = plane.rowStride
                val rowPadding = rowStride - pixelStride * image.width
                val bitmapWidth = image.width + rowPadding / max(1, pixelStride)

                val fullBitmap = Bitmap.createBitmap(bitmapWidth, image.height, Bitmap.Config.ARGB_8888)
                fullBitmap.copyPixelsFromBuffer(buffer)

                val croppedBitmap = if (bitmapWidth != image.width) {
                    Bitmap.createBitmap(fullBitmap, 0, 0, image.width, image.height).also {
                        fullBitmap.recycle()
                    }
                } else {
                    fullBitmap
                }

                val out = ByteArrayOutputStream()
                croppedBitmap.compress(Bitmap.CompressFormat.JPEG, 65, out)
                croppedBitmap.recycle()
                val jpegBytes = out.toByteArray()
                if (jpegBytes.isNotEmpty() && isCaptureActive) {
                    lastFrameSentAt = now
                    val base64 = Base64.encodeToString(jpegBytes, Base64.NO_WRAP)
                    frameListener?.invoke(base64)
                }
            } catch (_: Exception) {
            } finally {
                try {
                    image.close()
                } catch (_: Exception) {}
            }
        }, handler)

        virtualDisplay = projection.createVirtualDisplay(
            "BondhuScreenUnderstanding",
            capWidth,
            capHeight,
            densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader.surface,
            null,
            handler
        )

        isCaptureActive = true
        mainHandler.post {
            stateListener?.invoke(true, "Screen Understanding চালু হয়েছে। AI শুধু বর্তমান স্ক্রিন দেখতে পারবে।")
        }
    }

    private fun tearDownProjectionResources() {
        isCaptureActive = false
        try {
            virtualDisplay?.release()
        } catch (_: Exception) {}
        virtualDisplay = null

        try {
            imageReader?.setOnImageAvailableListener(null, null)
            imageReader?.close()
        } catch (_: Exception) {}
        imageReader = null

        try {
            mediaProjection?.unregisterCallback(projectionCallback)
            mediaProjection?.stop()
        } catch (_: Exception) {}
        mediaProjection = null

        try {
            captureThread?.quitSafely()
        } catch (_: Exception) {}
        captureThread = null
        captureHandler = null
    }

    private fun stopSelfCleanly(reasonMessage: String?) {
        tearDownProjectionResources()
        mainHandler.post {
            stateListener?.invoke(false, reasonMessage)
        }
        try {
            stopForeground(STOP_FOREGROUND_REMOVE)
        } catch (_: Exception) {}
        stopSelf()
    }

    override fun onDestroy() {
        tearDownProjectionResources()
        mainHandler.post {
            stateListener?.invoke(false, null)
        }
        super.onDestroy()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Bondhu AI Screen Share",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Shown only while Screen Share / Screen Understanding is actively turned on by user."
            }
            val nm = getSystemService(NotificationManager::class.java)
            nm?.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val stopIntent = Intent(this, BondhuScreenCaptureService::class.java).apply {
            action = ACTION_STOP
        }
        val stopPending = PendingIntent.getService(
            this,
            2,
            stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Bondhu AI Screen Share চালু আছে")
            .setContentText("শুধুমাত্র বর্তমান স্ক্রিন বোঝার জন্য সক্রিয় • বন্ধ করতে Stop চাপুন")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setOngoing(true)
            .addAction(android.R.drawable.ic_media_pause, "বন্ধ করুন (Stop)", stopPending)
            .build()
    }
}
