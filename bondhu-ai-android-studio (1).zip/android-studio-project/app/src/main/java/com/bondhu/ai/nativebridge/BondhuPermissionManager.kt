package com.bondhu.ai.nativebridge

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import org.json.JSONObject

class BondhuPermissionManager(private val activity: Activity) {

    companion object {
        const val REQ_CODE_RUNTIME = 9101
        const val REQ_CODE_STARTUP_SEQUENCE = 9102
        const val REQ_CODE_SINGLE_SETTINGS = 9103
        private const val PREFS_NAME = "bondhu_ai_prefs"
        private const val KEY_STARTUP_PREFIX = "startup_perm_asked_"
        private const val KEY_EVER_ASKED_PREFIX = "perm_ever_asked_"
    }

    private val prefs by lazy {
        activity.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    }

    private val startupQueue = ArrayDeque<String>()
    private var startupSequenceActive = false

    fun hasPermission(permission: String): Boolean {
        return ContextCompat.checkSelfPermission(activity, permission) == PackageManager.PERMISSION_GRANTED
    }

    fun hasMicPermission(): Boolean = hasPermission(Manifest.permission.RECORD_AUDIO)
    fun hasCameraPermission(): Boolean = hasPermission(Manifest.permission.CAMERA)
    fun hasCallPermission(): Boolean = hasPermission(Manifest.permission.CALL_PHONE)
    fun hasSmsPermission(): Boolean = hasPermission(Manifest.permission.SEND_SMS)
    fun hasContactsPermission(): Boolean = hasPermission(Manifest.permission.READ_CONTACTS)

    fun hasPostNotificationPermission(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            hasPermission(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            NotificationManagerCompat.from(activity).areNotificationsEnabled()
        }
    }

    fun hasMediaReadPermission(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            hasPermission(Manifest.permission.READ_MEDIA_IMAGES) || hasPermission(Manifest.permission.READ_MEDIA_VIDEO)
        } else {
            hasPermission(Manifest.permission.READ_EXTERNAL_STORAGE)
        }
    }

    fun hasNotificationAccess(): Boolean {
        val enabledPackages = NotificationManagerCompat.getEnabledListenerPackages(activity)
        return enabledPackages.contains(activity.packageName)
    }

    fun isAccessibilityEnabled(): Boolean {
        val expectedComponent = "${activity.packageName}/${BondhuAccessibilityService::class.java.name}"
        val enabledServices = Settings.Secure.getString(
            activity.contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        return enabledServices.split(':').any { it.equals(expectedComponent, ignoreCase = true) }
    }

    fun isIgnoringBatteryOptimizations(): Boolean {
        val pm = activity.getSystemService(Context.POWER_SERVICE) as PowerManager
        return pm.isIgnoringBatteryOptimizations(activity.packageName)
    }

    private fun wasAskedAtStartup(permission: String): Boolean {
        return prefs.getBoolean(KEY_STARTUP_PREFIX + permission, false)
    }

    private fun markAskedAtStartup(permission: String) {
        prefs.edit()
            .putBoolean(KEY_STARTUP_PREFIX + permission, true)
            .putBoolean(KEY_EVER_ASKED_PREFIX + permission, true)
            .apply()
    }

    private fun wasEverAsked(permission: String): Boolean {
        return prefs.getBoolean(KEY_EVER_ASKED_PREFIX + permission, false)
    }

    private fun markEverAsked(permission: String) {
        prefs.edit().putBoolean(KEY_EVER_ASKED_PREFIX + permission, true).apply()
    }

    private fun isPermanentlyDenied(permission: String): Boolean {
        if (hasPermission(permission)) return false
        return wasEverAsked(permission) && !ActivityCompat.shouldShowRequestPermissionRationale(activity, permission)
    }

    /**
     * Sequential startup permission flow:
     * Requests genuinely required runtime permissions strictly ONE AT A TIME in exact order:
     * 1. Camera -> 2. Microphone -> 3. Notifications (Android 13+) -> 4. Photos & Media
     * Already-granted or previously prompted permissions are NEVER re-prompted automatically.
     */
    fun startSequentialStartupPermissions() {
        if (startupSequenceActive) return

        val orderedStartupPerms = mutableListOf<String>()
        orderedStartupPerms.add(Manifest.permission.CAMERA)
        orderedStartupPerms.add(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            orderedStartupPerms.add(Manifest.permission.POST_NOTIFICATIONS)
            orderedStartupPerms.add(Manifest.permission.READ_MEDIA_IMAGES)
        } else {
            orderedStartupPerms.add(Manifest.permission.READ_EXTERNAL_STORAGE)
        }

        startupQueue.clear()
        for (perm in orderedStartupPerms) {
            if (!hasPermission(perm) && !wasAskedAtStartup(perm)) {
                startupQueue.addLast(perm)
            }
        }

        if (startupQueue.isEmpty()) return
        startupSequenceActive = true
        requestNextStartupPermission()
    }

    private fun requestNextStartupPermission() {
        while (startupQueue.isNotEmpty()) {
            val nextPerm = startupQueue.first()
            if (hasPermission(nextPerm)) {
                startupQueue.removeFirst()
                continue
            }
            markAskedAtStartup(nextPerm)
            activity.runOnUiThread {
                ActivityCompat.requestPermissions(
                    activity,
                    arrayOf(nextPerm),
                    REQ_CODE_STARTUP_SEQUENCE
                )
            }
            return
        }
        startupSequenceActive = false
    }

    fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        @Suppress("UNUSED_PARAMETER") grantResults: IntArray
    ): Boolean {
        for (perm in permissions) {
            markEverAsked(perm)
        }

        if (requestCode == REQ_CODE_STARTUP_SEQUENCE) {
            for (perm in permissions) {
                markAskedAtStartup(perm)
                if (startupQueue.firstOrNull() == perm) {
                    startupQueue.removeFirst()
                }
            }
            requestNextStartupPermission()
            return true
        }
        return requestCode == REQ_CODE_RUNTIME || requestCode == REQ_CODE_SINGLE_SETTINGS
    }

    fun requestCoreVoicePermissions() {
        startSequentialStartupPermissions()
    }

    fun openAppDetailsSettings(): Boolean {
        return try {
            activity.runOnUiThread {
                val intent = Intent(
                    Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    Uri.fromParts("package", activity.packageName, null)
                ).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                activity.startActivity(intent)
            }
            true
        } catch (_: Exception) {
            false
        }
    }

    fun openAppNotificationSettings(): Boolean {
        return try {
            activity.runOnUiThread {
                val intent = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).apply {
                        putExtra(Settings.EXTRA_APP_PACKAGE, activity.packageName)
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                } else {
                    Intent(
                        Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                        Uri.fromParts("package", activity.packageName, null)
                    ).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                }
                activity.startActivity(intent)
            }
            true
        } catch (_: Exception) {
            openAppDetailsSettings()
        }
    }

    fun requestSinglePermission(permissionKey: String): Boolean {
        val outcome = requestOrOpenPermissionSetting(permissionKey)
        return outcome.optBoolean("granted", false)
    }

    /**
     * Used by Centralized Permissions Settings:
     * - If already granted -> returns status="granted"
     * - If special system permission -> opens exact Android System Settings screen
     * - If runtime permission is promptable -> shows real Android permission dialog
     * - If runtime permission was permanently denied -> opens Android App Settings directly
     */
    fun requestOrOpenPermissionSetting(permissionKey: String): JSONObject {
        val key = permissionKey.trim().lowercase()

        when (key) {
            "accessibility" -> {
                if (isAccessibilityEnabled()) {
                    return resultJson(true, "granted", false, "Accessibility Service ইতিমধ্যেই চালু আছে।", granted = true)
                }
                activity.runOnUiThread {
                    val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    activity.startActivity(intent)
                }
                return resultJson(true, "settings_opened", true, "Accessibility Settings খোলা হয়েছে।", granted = false)
            }
            "notifications", "notification_listener" -> {
                if (hasNotificationAccess()) {
                    return resultJson(true, "granted", false, "Notification Access ইতিমধ্যেই চালু আছে।", granted = true)
                }
                activity.runOnUiThread {
                    val intent = Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    activity.startActivity(intent)
                }
                return resultJson(true, "settings_opened", true, "Notification Access Settings খোলা হয়েছে।", granted = false)
            }
            "battery" -> {
                if (isIgnoringBatteryOptimizations()) {
                    return resultJson(true, "granted", false, "Background Battery অনুমতি দেওয়া আছে।", granted = true)
                }
                activity.runOnUiThread {
                    val intent = Intent(
                        Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                        Uri.parse("package:${activity.packageName}")
                    ).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    activity.startActivity(intent)
                }
                return resultJson(true, "settings_opened", true, "Battery Optimization Settings খোলা হয়েছে।", granted = false)
            }
            "app_settings" -> {
                val opened = openAppDetailsSettings()
                return resultJson(opened, "settings_opened", opened, "App Settings খোলা হয়েছে।", granted = false)
            }
        }

        if (key == "post_notifications" || key == "post_notification" || key == "notification") {
            if (hasPostNotificationPermission()) {
                return resultJson(true, "granted", false, "Notification অনুমতি দেওয়া আছে।", granted = true)
            }
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) {
                val opened = openAppNotificationSettings()
                return resultJson(opened, "settings_opened", opened, "App Notification Settings খোলা হয়েছে।", granted = false)
            }
            val perm = Manifest.permission.POST_NOTIFICATIONS
            if (isPermanentlyDenied(perm)) {
                val opened = openAppNotificationSettings()
                return resultJson(opened, "settings_opened", opened, "Notification সেটিংস খোলা হয়েছে—এখান থেকে Allow করুন।", granted = false)
            }
            markEverAsked(perm)
            activity.runOnUiThread {
                ActivityCompat.requestPermissions(activity, arrayOf(perm), REQ_CODE_SINGLE_SETTINGS)
            }
            return resultJson(true, "prompted", false, "Notification অনুমতির ডায়ালগ দেখানো হয়েছে।", granted = false)
        }

        if (key == "media" || key == "storage" || key == "photos") {
            if (hasMediaReadPermission()) {
                return resultJson(true, "granted", false, "Photos & Media অনুমতি দেওয়া আছে।", granted = true)
            }
            val perms = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                arrayOf(Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.READ_MEDIA_VIDEO)
            } else {
                arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
            }
            if (perms.any { isPermanentlyDenied(it) }) {
                val opened = openAppDetailsSettings()
                return resultJson(opened, "settings_opened", opened, "App Permissions Settings খোলা হয়েছে।", granted = false)
            }
            perms.forEach { markEverAsked(it) }
            activity.runOnUiThread {
                ActivityCompat.requestPermissions(activity, perms, REQ_CODE_SINGLE_SETTINGS)
            }
            return resultJson(true, "prompted", false, "Photos & Media অনুমতির ডায়ালগ দেখানো হয়েছে।", granted = false)
        }

        val mapped = when (key) {
            "microphone", "mic" -> Manifest.permission.RECORD_AUDIO
            "camera" -> Manifest.permission.CAMERA
            "call", "phone" -> Manifest.permission.CALL_PHONE
            "sms" -> Manifest.permission.SEND_SMS
            "contacts" -> Manifest.permission.READ_CONTACTS
            else -> return resultJson(false, "unsupported", false, "অজানা পারমিশন: $permissionKey", granted = false)
        }

        if (hasPermission(mapped)) {
            return resultJson(true, "granted", false, "এই অনুমতি ইতিমধ্যেই দেওয়া আছে।", granted = true)
        }

        if (isPermanentlyDenied(mapped)) {
            val opened = openAppDetailsSettings()
            return resultJson(opened, "settings_opened", opened, "App Settings খোলা হয়েছে—Permissions থেকে Allow করুন।", granted = false)
        }

        markEverAsked(mapped)
        activity.runOnUiThread {
            ActivityCompat.requestPermissions(activity, arrayOf(mapped), REQ_CODE_SINGLE_SETTINGS)
        }
        return resultJson(true, "prompted", false, "অনুমতির ডায়ালগ দেখানো হয়েছে।", granted = false)
    }

    fun getDetailedPermissionsJson(): JSONObject {
        fun runtimeState(granted: Boolean, perm: String): String {
            return when {
                granted -> "granted"
                isPermanentlyDenied(perm) -> "denied_permanent"
                else -> "prompt"
            }
        }

        val mediaPerm = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            Manifest.permission.READ_MEDIA_IMAGES
        } else {
            Manifest.permission.READ_EXTERNAL_STORAGE
        }
        val notifStatus = if (hasPostNotificationPermission()) {
            "granted"
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU && isPermanentlyDenied(Manifest.permission.POST_NOTIFICATIONS)) {
            "denied_permanent"
        } else {
            "prompt"
        }

        return JSONObject().apply {
            put("isAndroidApk", true)
            put("camera", runtimeState(hasCameraPermission(), Manifest.permission.CAMERA))
            put("microphone", runtimeState(hasMicPermission(), Manifest.permission.RECORD_AUDIO))
            put("post_notifications", notifStatus)
            put("media", runtimeState(hasMediaReadPermission(), mediaPerm))
            put("call", runtimeState(hasCallPermission(), Manifest.permission.CALL_PHONE))
            put("sms", runtimeState(hasSmsPermission(), Manifest.permission.SEND_SMS))
            put("contacts", runtimeState(hasContactsPermission(), Manifest.permission.READ_CONTACTS))
            put("accessibility", if (isAccessibilityEnabled()) "granted" else "prompt")
            put("notifications", if (hasNotificationAccess()) "granted" else "prompt")
            put("battery", if (isIgnoringBatteryOptimizations()) "granted" else "prompt")
        }
    }

    private fun resultJson(
        ok: Boolean,
        status: String,
        openedSettings: Boolean,
        message: String,
        granted: Boolean
    ): JSONObject {
        return JSONObject().apply {
            put("ok", ok)
            put("status", status)
            put("openedSettings", openedSettings)
            put("granted", granted)
            put("message", message)
        }
    }
}
