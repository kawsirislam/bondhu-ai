package com.bondhu.ai.nativebridge

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import org.json.JSONArray
import org.json.JSONObject

class BondhuNotificationListenerService : NotificationListenerService() {

    companion object {
        @Volatile
        var instance: BondhuNotificationListenerService? = null
            private set

        private val sensitiveKeywords = listOf(
            "otp", "ওটিপি", "one time password", "verification code", "verify code", "security code",
            "ভেরিফিকেশন কোড", "auth code", "login code", "2fa", "mfa", "authenticator", "passcode",
            "password", "পাসওয়ার্ড", "পাসওয়ার্ড", "secret", "cvv", "cvc", "pin", "পিন",
            "atm", "card number", "কার্ড নম্বর", "account number", "একাউন্ট নম্বর", "অ্যাকাউন্ট নম্বর",
            "bank", "ব্যাংক", "routing", "iban", "swift", "ifsc", "bkash", "বিকাশ",
            "nagad", "নগদ", "rocket", "রকেট", "upay", "উপায়", "balance", "ব্যালেন্স",
            "credited", "debited", "transaction", "txn", "ট্রানজেকশন", "bearer ", "session token",
            "reset link", "magic link", "login link", "access token", "private key"
        )

        private val codeWithContextRegex = Regex("(?i)\\b(?:otp|pin|code|কোড|পিন)\\b[^\\d]{0,16}\\d{4,8}\\b")
        private val standaloneCodeRegex = Regex("\\b\\d{4,8}\\b")
        private val cardOrAccountRegex = Regex("\\b(?:\\d[ -]?){11,19}\\b")
        private val tokenRegex = Regex("\\b[A-Za-z0-9_\\-]{24,}\\b")
        private val authUrlParamRegex = Regex("(?i)(?:token|code|otp|auth|secret|key)=")

        fun containsSensitiveContent(title: String, text: String): Boolean {
            val combined = "$title $text".lowercase()
            if (sensitiveKeywords.any { combined.contains(it) }) return true
            if (codeWithContextRegex.containsMatchIn(combined)) return true
            if (cardOrAccountRegex.containsMatchIn(combined)) return true
            if (tokenRegex.containsMatchIn("$title $text")) return true
            if (authUrlParamRegex.containsMatchIn(combined)) return true
            if (standaloneCodeRegex.containsMatchIn(text) && (combined.contains("code") || combined.contains("কোড") || combined.contains("verify"))) {
                return true
            }
            return false
        }
    }

    override fun onListenerConnected() {
        super.onListenerConnected()
        instance = this
    }

    override fun onListenerDisconnected() {
        instance = null
        super.onListenerDisconnected()
    }

    fun readSafeNotifications(confirmed: Boolean): JSONObject {
        if (!confirmed) {
            return JSONObject().apply {
                put("ok", false)
                put("errorCode", "CONFIRMATION_REQUIRED")
                put("message", "নোটিফিকেশন পড়তে ব্যবহারকারীর অনুমতি প্রয়োজন।")
            }
        }

        val list = try {
            activeNotifications ?: emptyArray<StatusBarNotification>()
        } catch (_: SecurityException) {
            return JSONObject().apply {
                put("ok", false)
                put("errorCode", "NOTIFICATION_SERVICE_DISABLED")
                put("message", "Notification Listener অনুমতি চালু করা নেই।")
            }
        }

        val arr = JSONArray()
        for (sbn in list.take(15)) {
            val extras = sbn.notification?.extras ?: continue
            val rawTitle = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString()?.trim() ?: ""
            val rawText = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString()?.trim()
                ?: extras.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString()?.trim()
                ?: ""

            val isSensitive = containsSensitiveContent(rawTitle, rawText)
            val safeTitle = if (isSensitive && (tokenRegex.containsMatchIn(rawTitle) || cardOrAccountRegex.containsMatchIn(rawTitle) || standaloneCodeRegex.containsMatchIn(rawTitle))) {
                "[সুরক্ষিত শিরোনাম গোপন রাখা হয়েছে]"
            } else {
                rawTitle
            }

            arr.put(JSONObject().apply {
                put("packageName", sbn.packageName)
                put("title", safeTitle)
                put("text", if (isSensitive) "[সুরক্ষিত: গোপনীয় OTP/Password/Banking/Auth তথ্য গোপন রাখা হয়েছে]" else rawText)
                put("redacted", isSensitive)
            })
        }

        return JSONObject().apply {
            put("ok", true)
            put("message", "${arr.length()}টি সক্রিয় নোটিফিকেশন নিরাপদভাবে পড়া হয়েছে।")
            put("details", JSONObject().put("notifications", arr))
        }
    }
}
