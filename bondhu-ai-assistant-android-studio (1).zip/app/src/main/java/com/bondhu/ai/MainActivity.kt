package com.bondhu.ai

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Looper
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.util.Base64
import android.view.View
import android.webkit.CookieManager
import android.webkit.PermissionRequest
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ProgressBar
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.bondhu.ai.nativebridge.BondhuMediaPickerHost
import com.bondhu.ai.nativebridge.BondhuPermissionManager
import com.bondhu.ai.nativebridge.BondhuWebViewBridge
import org.json.JSONObject
import java.io.File
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import kotlin.math.max

class MainActivity : AppCompatActivity(), BondhuMediaPickerHost {

    private lateinit var rootContainer: FrameLayout
    private lateinit var webView: WebView
    private lateinit var loadingProgress: ProgressBar
    private lateinit var errorContainer: LinearLayout
    private lateinit var permissionManager: BondhuPermissionManager

    private var filePathCallback: ValueCallback<Array<Uri>>? = null
    private var cameraPhotoUri: Uri? = null
    private var pendingWebPermissionRequest: PermissionRequest? = null

    private val prefs by lazy { getSharedPreferences("bondhu_ai_prefs", Context.MODE_PRIVATE) }

    private val fileChooserLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val callback = filePathCallback ?: return@registerForActivityResult
        filePathCallback = null

        var results: Array<Uri>? = null
        if (result.resultCode == Activity.RESULT_OK) {
            val data = result.data
            if (data == null || (data.data == null && data.clipData == null)) {
                cameraPhotoUri?.let { results = arrayOf(it) }
            } else {
                val clipData = data.clipData
                if (clipData != null && clipData.itemCount > 0) {
                    results = Array(clipData.itemCount) { idx -> clipData.getItemAt(idx).uri }
                } else {
                    data.data?.let { results = arrayOf(it) }
                }
            }
        }
        callback.onReceiveValue(results)
    }

    private val nativeMediaPickerLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val pickedUri = result.data?.data
        if (result.resultCode != Activity.RESULT_OK || pickedUri == null) {
            dispatchMediaPickedEventToWebView(
                JSONObject().apply {
                    put("ok", false)
                    put("cancelled", true)
                    put("message", "ব্যবহারকারী ছবি বা ফাইল নির্বাচন বাতিল করেছেন।")
                }
            )
            return@registerForActivityResult
        }

        Thread {
            val payload = readPickedMediaPayload(pickedUri)
            runOnUiThread {
                dispatchMediaPickedEventToWebView(payload)
            }
        }.start()
    }

    private val webPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { grantMap ->
        val req = pendingWebPermissionRequest ?: return@registerForActivityResult
        pendingWebPermissionRequest = null
        val allowedResources = mutableListOf<String>()
        for (res in req.resources) {
            when (res) {
                PermissionRequest.RESOURCE_AUDIO_CAPTURE -> {
                    if (grantMap[Manifest.permission.RECORD_AUDIO] == true || permissionManager.hasMicPermission()) {
                        allowedResources.add(res)
                    }
                }
                PermissionRequest.RESOURCE_VIDEO_CAPTURE -> {
                    if (grantMap[Manifest.permission.CAMERA] == true || permissionManager.hasCameraPermission()) {
                        allowedResources.add(res)
                    }
                }
                else -> allowedResources.add(res)
            }
        }
        if (allowedResources.isNotEmpty()) {
            req.grant(allowedResources.toTypedArray())
        } else {
            req.deny()
        }
    }

    private val wakeWordReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == "com.bondhu.ai.WAKE_WORD_DETECTED") {
                val bringFront = Intent(this@MainActivity, MainActivity::class.java).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                }
                startActivity(bringFront)
                webView.evaluateJavascript(
                    "window.dispatchEvent(new CustomEvent('bondhu-wake-word', { detail: { wakeWord: 'বন্ধু' } }));",
                    null
                )
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        rootContainer = findViewById(R.id.rootContainer)
        webView = findViewById(R.id.bondhuWebView)
        loadingProgress = findViewById(R.id.loadingProgress)
        errorContainer = findViewById(R.id.errorContainer)
        permissionManager = BondhuPermissionManager(this)

        setupKeyboardWindowInsets()
        setupWebView()
        setupErrorButtons()
        setupBackNavigation()

        val filter = IntentFilter("com.bondhu.ai.WAKE_WORD_DETECTED")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(wakeWordReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("UnspecifiedRegisterReceiverFlag")
            registerReceiver(wakeWordReceiver, filter)
        }

        permissionManager.requestCoreVoicePermissions()
        loadBondhuApp()
    }

    private fun setupKeyboardWindowInsets() {
        ViewCompat.setOnApplyWindowInsetsListener(rootContainer) { view, insets ->
            val imeInsets = insets.getInsets(WindowInsetsCompat.Type.ime())
            val sysInsets = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            val bottomPadding = max(imeInsets.bottom, sysInsets.bottom)
            view.setPadding(sysInsets.left, sysInsets.top, sysInsets.right, bottomPadding)
            insets
        }
    }

    private fun isTrustedBondhuUrl(rawUrl: String?): Boolean {
        if (rawUrl.isNullOrBlank()) return false
        val uri = try {
            Uri.parse(rawUrl)
        } catch (_: Exception) {
            return false
        }
        if (!"https".equals(uri.scheme, ignoreCase = true)) return false
        val host = uri.host?.lowercase()?.trim() ?: return false
        val configuredHost = try {
            Uri.parse(getConfiguredServerUrl()).host?.lowercase()?.trim()
        } catch (_: Exception) {
            null
        }
        return host == "bondhu-ai-4973.ai.studio" ||
            host == "kowsar-ai.ai.studio" ||
            host.endsWith(".ai.studio") ||
            host.endsWith(".run.app") ||
            (configuredHost != null && host == configuredHost)
    }

    private fun isInternalNavigationUri(uri: Uri): Boolean {
        val urlStr = uri.toString()
        if (isTrustedBondhuUrl(urlStr)) return true
        val host = uri.host?.lowercase()?.trim() ?: return false
        return "https".equals(uri.scheme, ignoreCase = true) && (
            host == "accounts.google.com" ||
                host.endsWith(".google.com") && host.contains("accounts") ||
                host.endsWith(".firebaseapp.com") ||
                host.endsWith(".web.app") ||
                host == "appleid.apple.com"
            )
    }

    private fun isBridgeCallerAuthorized(): Boolean {
        if (!::webView.isInitialized) return false
        if (Looper.myLooper() == Looper.getMainLooper()) {
            return isTrustedBondhuUrl(webView.url)
        }
        var trusted = false
        val latch = CountDownLatch(1)
        runOnUiThread {
            trusted = try {
                isTrustedBondhuUrl(webView.url)
            } catch (_: Exception) {
                false
            }
            latch.countDown()
        }
        try {
            latch.await(500, TimeUnit.MILLISECONDS)
        } catch (_: InterruptedException) {
            trusted = false
        }
        return trusted
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        val cookieManager = CookieManager.getInstance()
        cookieManager.setAcceptCookie(true)
        cookieManager.setAcceptThirdPartyCookies(webView, true)

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            mediaPlaybackRequiresUserGesture = false
            allowFileAccess = false
            allowContentAccess = true
            setSupportMultipleWindows(false)
            useWideViewPort = true
            loadWithOverviewMode = true
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            cacheMode = WebSettings.LOAD_DEFAULT
            userAgentString = "$userAgentString BondhuAIAndroidAPK/1.1"
        }

        // Inject origin-guarded Bondhu Native Bridge directly as window.BondhuAndroidBridge
        webView.addJavascriptInterface(
            BondhuWebViewBridge(this) { isBridgeCallerAuthorized() },
            "BondhuAndroidBridge"
        )

        webView.webViewClient = object : WebViewClient() {
            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                errorContainer.visibility = View.GONE
                loadingProgress.visibility = View.VISIBLE
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                loadingProgress.visibility = View.GONE
                CookieManager.getInstance().flush()
            }

            override fun onReceivedError(
                view: WebView?,
                request: WebResourceRequest?,
                error: WebResourceError?
            ) {
                if (request?.isForMainFrame == true) {
                    loadingProgress.visibility = View.GONE
                    errorContainer.visibility = View.VISIBLE
                }
            }

            override fun shouldOverrideUrlLoading(
                view: WebView?,
                request: WebResourceRequest?
            ): Boolean {
                val uri = request?.url ?: return false
                val scheme = uri.scheme?.lowercase() ?: ""

                if (scheme == "tel" || scheme == "sms" || scheme == "mailto") {
                    try {
                        startActivity(Intent(Intent.ACTION_VIEW, uri))
                    } catch (_: Exception) {}
                    return true
                }

                if (scheme == "intent") {
                    try {
                        val intent = Intent.parseUri(uri.toString(), Intent.URI_INTENT_SCHEME)
                        val fallbackUrl = intent.getStringExtra("browser_fallback_url")
                        if (!fallbackUrl.isNullOrBlank()) {
                            val fallbackUri = Uri.parse(fallbackUrl)
                            if (isInternalNavigationUri(fallbackUri)) {
                                view?.loadUrl(fallbackUrl)
                                return true
                            }
                        }
                        if (intent.resolveActivity(packageManager) != null) {
                            startActivity(intent)
                        }
                    } catch (_: Exception) {}
                    return true
                }

                // Keep all Bondhu AI domains, subdomains, redirects, and OAuth inside WebView
                if (isInternalNavigationUri(uri)) {
                    return false
                }

                // Only genuine external third-party links open outside the app
                if (scheme == "https" || scheme == "http") {
                    try {
                        startActivity(Intent(Intent.ACTION_VIEW, uri))
                    } catch (_: Exception) {}
                    return true
                }
                return false
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                loadingProgress.progress = newProgress
                loadingProgress.visibility = if (newProgress in 1..99) View.VISIBLE else View.GONE
            }

            override fun onPermissionRequest(request: PermissionRequest?) {
                if (request == null) return
                runOnUiThread {
                    val missingPerms = mutableListOf<String>()
                    val directlyGrant = mutableListOf<String>()

                    for (res in request.resources) {
                        when (res) {
                            PermissionRequest.RESOURCE_AUDIO_CAPTURE -> {
                                if (permissionManager.hasMicPermission()) {
                                    directlyGrant.add(res)
                                } else {
                                    missingPerms.add(Manifest.permission.RECORD_AUDIO)
                                }
                            }
                            PermissionRequest.RESOURCE_VIDEO_CAPTURE -> {
                                if (permissionManager.hasCameraPermission()) {
                                    directlyGrant.add(res)
                                } else {
                                    missingPerms.add(Manifest.permission.CAMERA)
                                }
                            }
                            else -> directlyGrant.add(res)
                        }
                    }

                    if (missingPerms.isNotEmpty()) {
                        pendingWebPermissionRequest = request
                        webPermissionLauncher.launch(missingPerms.toTypedArray())
                    } else if (directlyGrant.isNotEmpty()) {
                        request.grant(directlyGrant.toTypedArray())
                    } else {
                        request.deny()
                    }
                }
            }

            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: FileChooserParams?
            ): Boolean {
                this@MainActivity.filePathCallback?.onReceiveValue(null)
                this@MainActivity.filePathCallback = filePathCallback

                val galleryIntent = Intent(Intent.ACTION_GET_CONTENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "*/*"
                    putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("image/*", "video/*", "application/pdf"))
                }

                val extraIntents = mutableListOf<Intent>()
                if (ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                    val photoFile = File.createTempFile("bondhu_cam_", ".jpg", cacheDir)
                    cameraPhotoUri = FileProvider.getUriForFile(
                        this@MainActivity,
                        "$packageName.fileprovider",
                        photoFile
                    )
                    val cameraIntent = Intent(MediaStore.ACTION_IMAGE_CAPTURE).apply {
                        putExtra(MediaStore.EXTRA_OUTPUT, cameraPhotoUri)
                    }
                    extraIntents.add(cameraIntent)
                }

                val chooser = Intent.createChooser(galleryIntent, "ছবি, ভিডিও বা ফাইল নির্বাচন করুন").apply {
                    if (extraIntents.isNotEmpty()) {
                        putExtra(Intent.EXTRA_INITIAL_INTENTS, extraIntents.toTypedArray())
                    }
                }
                fileChooserLauncher.launch(chooser)
                return true
            }
        }
    }

    override fun launchNativeMediaPicker(mediaType: String): Boolean {
        val mime = when (mediaType.trim().lowercase()) {
            "image", "photo", "picture" -> "image/*"
            "video" -> "video/*"
            else -> "*/*"
        }
        return try {
            runOnUiThread {
                val pickIntent = Intent(Intent.ACTION_GET_CONTENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = mime
                    if (mime == "*/*") {
                        putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("image/*", "video/*", "application/pdf"))
                    }
                }
                val chooser = Intent.createChooser(pickIntent, "ছবি, ভিডিও বা ফাইল নির্বাচন করুন")
                nativeMediaPickerLauncher.launch(chooser)
            }
            true
        } catch (_: Exception) {
            false
        }
    }

    private fun readPickedMediaPayload(uri: Uri): JSONObject {
        var displayName = "selected_file"
        var sizeBytes = 0L
        val mimeType = contentResolver.getType(uri) ?: "application/octet-stream"

        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null)?.use { c ->
            if (c.moveToFirst()) {
                val nameIdx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                val sizeIdx = c.getColumnIndex(OpenableColumns.SIZE)
                if (nameIdx >= 0) displayName = c.getString(nameIdx) ?: displayName
                if (sizeIdx >= 0) sizeBytes = c.getLong(sizeIdx)
            }
        }

        var dataUrl: String? = null
        if (mimeType.startsWith("image/") && sizeBytes in 1..4_000_000L) {
            try {
                contentResolver.openInputStream(uri)?.use { stream ->
                    val bytes = stream.readBytes()
                    if (bytes.isNotEmpty() && bytes.size <= 4_000_000) {
                        val b64 = Base64.encodeToString(bytes, Base64.NO_WRAP)
                        dataUrl = "data:$mimeType;base64,$b64"
                    }
                }
            } catch (_: Exception) {}
        }

        return JSONObject().apply {
            put("ok", true)
            put("name", displayName)
            put("mimeType", mimeType)
            put("sizeBytes", sizeBytes)
            if (dataUrl != null) put("dataUrl", dataUrl)
            put("message", "$displayName নির্বাচন করা হয়েছে।")
        }
    }

    private fun dispatchMediaPickedEventToWebView(payload: JSONObject) {
        if (!::webView.isInitialized) return
        val jsonLiteral = JSONObject.quote(payload.toString())
        webView.evaluateJavascript(
            "(function(){try{var d=JSON.parse($jsonLiteral);window.dispatchEvent(new CustomEvent('bondhu-native-media-picked',{detail:d}));}catch(e){}})();",
            null
        )
    }

    private fun setupErrorButtons() {
        findViewById<Button>(R.id.btnRetry).setOnClickListener {
            loadBondhuApp()
        }
        findViewById<Button>(R.id.btnServerSettings).setOnClickListener {
            showServerUrlDialog()
        }
    }

    private fun setupBackNavigation() {
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (webView.canGoBack()) {
                    webView.goBack()
                } else {
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                }
            }
        })
    }

    private fun getConfiguredServerUrl(): String {
        return prefs.getString("server_url", null)?.takeIf { it.isNotBlank() }
            ?: getString(R.string.bondhu_server_url)
    }

    private fun loadBondhuApp() {
        errorContainer.visibility = View.GONE
        webView.loadUrl(getConfiguredServerUrl())
    }

    private fun showServerUrlDialog() {
        val input = EditText(this).apply {
            setText(getConfiguredServerUrl())
            setSingleLine(true)
        }
        AlertDialog.Builder(this)
            .setTitle("Bondhu AI Server URL")
            .setMessage("মূল সাইট (kowsar-ai.ai.studio) বা Pre/Dev URL লিখুন:")
            .setView(input)
            .setPositiveButton("Save & Load") { _, _ ->
                val url = input.text.toString().trim()
                if (url.startsWith("https://")) {
                    prefs.edit().putString("server_url", url).apply()
                    loadBondhuApp()
                }
            }
            .setNeutralButton("Reset Default") { _, _ ->
                val defaultUrl = getString(R.string.bondhu_server_url)
                prefs.edit().putString("server_url", defaultUrl).apply()
                loadBondhuApp()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    override fun onDestroy() {
        try {
            unregisterReceiver(wakeWordReceiver)
        } catch (_: Exception) {}
        webView.destroy()
        super.onDestroy()
    }
}
