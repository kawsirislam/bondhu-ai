package com.bondhu.ai.nativebridge

import android.accessibilityservice.AccessibilityService
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import org.json.JSONArray
import org.json.JSONObject

class BondhuAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: BondhuAccessibilityService? = null
            private set
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Event-driven screen updates only when service is explicitly enabled by user
    }

    override fun onInterrupt() {
        // Required lifecycle hook
    }

    fun performGlobal(actionId: Int): Boolean {
        return try {
            performGlobalAction(actionId)
        } catch (_: Exception) {
            false
        }
    }

    fun getActivePackageName(): String? {
        return try {
            rootInActiveWindow?.packageName?.toString()
        } catch (_: Exception) {
            null
        }
    }

    fun executeUiAction(instruction: String, targetText: String, confirmed: Boolean): JSONObject {
        if (!confirmed) {
            return JSONObject().apply {
                put("ok", false)
                put("errorCode", "CONFIRMATION_REQUIRED")
                put("message", "Accessibility অ্যাকশনের আগে ব্যবহারকারীর অনুমতি প্রয়োজন।")
            }
        }

        val lowerInstr = instruction.lowercase()

        // Global Navigation & System Actions
        if (lowerInstr.contains("recent") || lowerInstr.contains("রিসেন্ট")) {
            val ok = performGlobal(GLOBAL_ACTION_RECENTS)
            return JSONObject().apply {
                put("ok", ok)
                put("message", if (ok) "রিসেন্ট অ্যাপস স্ক্রিন খোলা হয়েছে।" else "রিসেন্ট অ্যাপস খোলা যায়নি।")
            }
        }
        if (lowerInstr.contains("home") || lowerInstr.contains("হোম")) {
            val ok = performGlobal(GLOBAL_ACTION_HOME)
            return JSONObject().apply {
                put("ok", ok)
                put("message", if (ok) "Home স্ক্রিনে ফিরে যাওয়া হয়েছে।" else "Home স্ক্রিনে যাওয়া যায়নি।")
            }
        }
        if (lowerInstr.contains("back") || lowerInstr.contains("পিছনে") || lowerInstr.contains("ব্যাক")) {
            val ok = performGlobal(GLOBAL_ACTION_BACK)
            return JSONObject().apply {
                put("ok", ok)
                put("message", if (ok) "পূর্বের স্ক্রিনে ফিরে যাওয়া হয়েছে (Back)।" else "Back অ্যাকশন করা যায়নি।")
            }
        }
        if (lowerInstr.contains("power") || lowerInstr.contains("শাটডাউন") || lowerInstr.contains("পাওয়ার")) {
            val ok = performGlobal(GLOBAL_ACTION_POWER_DIALOG)
            return JSONObject().apply {
                put("ok", ok)
                put("message", if (ok) "অ্যান্ড্রয়েডের অফিশিয়াল পাওয়ার ডায়ালগ খোলা হয়েছে (শাটডাউন/রিস্টার্ট)।" else "পাওয়ার মেনু খোলা যায়নি।")
            }
        }

        val root = rootInActiveWindow ?: return JSONObject().apply {
            put("ok", false)
            put("errorCode", "NO_ACTIVE_WINDOW")
            put("message", "বর্তমান স্ক্রিনের তথ্য পড়া যায়নি।")
        }

        val matches = root.findAccessibilityNodeInfosByText(targetText)
        if (!matches.isNullOrEmpty()) {
            for (node in matches) {
                if (node.isPassword) {
                    return JSONObject().apply {
                        put("ok", false)
                        put("errorCode", "PASSWORD_FIELD_PROTECTED")
                        put("message", "নিরাপত্তার কারণে পাসওয়ার্ড বা গোপন ইনপুট ফিল্ড অ্যাক্সেস করা নিষিদ্ধ।")
                    }
                }
                if (lowerInstr.contains("type") || lowerInstr.contains("write") || lowerInstr.contains("লিখ")) {
                    val textToWrite = instruction.replace(Regex("^(type|write|লিখো|টাইপ করো)\\s*", RegexOption.IGNORE_CASE), "").ifBlank { targetText }
                    val args = Bundle().apply {
                        putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, textToWrite)
                    }
                    val ok = node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
                    if (ok) {
                        return JSONObject().apply {
                            put("ok", true)
                            put("message", "\"$textToWrite\" টেক্সট লেখা হয়েছে।")
                        }
                    }
                } else {
                    var targetNode: AccessibilityNodeInfo? = node
                    while (targetNode != null && !targetNode.isClickable) {
                        targetNode = targetNode.parent
                    }
                    if (targetNode != null && targetNode.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                        return JSONObject().apply {
                            put("ok", true)
                            put("message", "\"$targetText\" উপাদানে ট্যাপ/ক্লিক করা হয়েছে।")
                        }
                    }
                }
            }
        }

        if (lowerInstr.contains("scroll") || lowerInstr.contains("নিচে") || lowerInstr.contains("উপরে")) {
            val action = if (lowerInstr.contains("up") || lowerInstr.contains("উপরে")) {
                AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
            } else {
                AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
            }
            val scrollable = findScrollableNode(root)
            if (scrollable != null && scrollable.performAction(action)) {
                return JSONObject().apply {
                    put("ok", true)
                    put("message", "স্ক্রিন স্ক্রল করা হয়েছে।")
                }
            }
        }

        val labels = JSONArray()
        collectSafeTextNodes(root, labels, 20)
        return JSONObject().apply {
            put("ok", false)
            put("errorCode", "UI_TARGET_NOT_FOUND")
            put("message", "স্ক্রিনে \"$targetText\" খুঁজে পাওয়া যায়নি।")
            put("details", JSONObject().put("visibleLabels", labels))
        }
    }

    private fun findScrollableNode(node: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        if (node == null) return null
        if (node.isScrollable) return node
        for (i in 0 until node.childCount) {
            val found = findScrollableNode(node.getChild(i))
            if (found != null) return found
        }
        return null
    }

    private fun collectSafeTextNodes(node: AccessibilityNodeInfo?, out: JSONArray, limit: Int) {
        if (node == null || out.length() >= limit) return
        if (!node.isPassword) {
            val txt = node.text?.toString()?.trim()
            if (!txt.isNullOrEmpty() && !Regex("\\b\\d{4,8}\\b").containsMatchIn(txt)) {
                out.put(txt)
            }
        }
        for (i in 0 until node.childCount) {
            collectSafeTextNodes(node.getChild(i), out, limit)
        }
    }
}
