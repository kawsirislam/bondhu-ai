package com.bondhu.ai.nativebridge

import android.app.Activity
import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.ConnectivityManager
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.StatFs
import android.os.SystemClock
import android.webkit.JavascriptInterface
import org.json.JSONObject

interface BondhuMediaPickerHost {
    fun launchNativeMediaPicker(mediaType: String): Boolean
}

/**
 * Exposed to Android WebView via:
 * webView.addJavascriptInterface(BondhuWebViewBridge(this) { isBridgeCallerAuthorized() }, "BondhuAndroidBridge")
 * Every call checks active WebView URL origin so external websites cannot invoke native bridge methods.
 */
class BondhuWebViewBridge(
    private val activity: Activity,
    private val isOriginAuthorized: () -> Boolean = { false }
) {

    private val permissionManager = BondhuPermissionManager(activity)
    private val intentExecutor = BondhuIntentExecutor(activity)

    private fun unauthorizedOriginJson(): String {
        return JSONObject().apply {
            put("ok", false)
            put("errorCode", "UNTRUSTED_ORIGIN")
            put("message", "Security Policy: অনুমোদিত Bondhu AI ডোমেইন ছাড়া এই ফিচার ব্যবহার করা যাবে না।")
        }.toString()
    }

    @JavascriptInterface
    fun getCapabilitiesJson(): String {
        if (!isOriginAuthorized()) {
            return JSONObject().apply {
                put("isAndroidApk", false)
                put("originBlocked", true)
            }.toString()
        }
        return JSONObject().apply {
            put("isAndroidApk", true)
            put("hasAccessibility", permissionManager.isAccessibilityEnabled())
            put("hasNotificationAccess", permissionManager.hasNotificationAccess())
            put("hasPostNotificationPermission", permissionManager.hasPostNotificationPermission())
            put("hasMediaPermission", permissionManager.hasMediaReadPermission())
            put("hasCallPermission", permissionManager.hasCallPermission())
            put("hasSmsPermission", permissionManager.hasSmsPermission())
            put("hasMicPermission", permissionManager.hasMicPermission())
            put("hasCameraPermission", permissionManager.hasCameraPermission())
            put("hasBackgroundService", BondhuForegroundVoiceService.isServiceRunning)
        }.toString()
    }

    @JavascriptInterface
    fun checkPermissionsJson(): String {
        if (!isOriginAuthorized()) return unauthorizedOriginJson()
        val caps = JSONObject(getCapabilitiesJson())
        return JSONObject().apply {
            put("ok", true)
            put("message", "Android APK পারমিশন স্ট্যাটাস পাওয়া গেছে।")
            put("details", caps)
        }.toString()
    }

    @JavascriptInterface
    fun requestRuntimePermission(permissionKey: String): Boolean {
        if (!isOriginAuthorized()) return false
        return permissionManager.requestSinglePermission(permissionKey)
    }

    @JavascriptInterface
    fun openApp(appNameOrPackage: String): String {
        if (!isOriginAuthorized()) return unauthorizedOriginJson()
        return intentExecutor.openApp(appNameOrPackage).toString()
    }

    @JavascriptInterface
    fun findInstalledApp(query: String): String {
        if (!isOriginAuthorized()) return unauthorizedOriginJson()
        return intentExecutor.findInstalledApp(query).toString()
    }

    @JavascriptInterface
    fun makePhoneCall(contactOrNumber: String): String {
        if (!isOriginAuthorized()) return unauthorizedOriginJson()
        return intentExecutor.makePhoneCall(contactOrNumber).toString()
    }

    @JavascriptInterface
    fun prepareOrSendSms(contactOrNumber: String, textBody: String, confirmed: Boolean): String {
        if (!isOriginAuthorized()) return unauthorizedOriginJson()
        return intentExecutor.prepareOrSendSms(contactOrNumber, textBody, confirmed).toString()
    }

    @JavascriptInterface
    fun openNativeCamera(): String {
        if (!isOriginAuthorized()) return unauthorizedOriginJson()
        return intentExecutor.openNativeCamera().toString()
    }

    @JavascriptInterface
    fun shareContent(text: String, title: String, url: String): String {
        if (!isOriginAuthorized()) return unauthorizedOriginJson()
        return intentExecutor.shareContent(text, title, url).toString()
    }

    @JavascriptInterface
    fun createNotification(title: String, body: String, confirmed: Boolean): String {
        if (!isOriginAuthorized()) return unauthorizedOriginJson()
        return intentExecutor.createLocalNotification(title, body, confirmed).toString()
    }

    @JavascriptInterface
    fun requestMediaPicker(mediaType: String): String {
        if (!isOriginAuthorized()) return unauthorizedOriginJson()
        val host = activity as? BondhuMediaPickerHost
            ?: return JSONObject().apply {
                put("ok", false)
                put("errorCode", "MEDIA_PICKER_UNAVAILABLE")
                put("message", "মিডিয়া পিকার চালু করা সম্ভব হয়নি।")
            }.toString()
        val launched = host.launchNativeMediaPicker(mediaType)
        return JSONObject().apply {
            put("ok", launched)
            put("message", if (launched) "ছবি/ফাইল বাছাই স্ক্রিন খোলা হয়েছে।" else "ফাইল বাছাই চালু করা যায়নি।")
        }.toString()
    }

    @JavascriptInterface
    fun readActiveNotifications(confirmed: Boolean): String {
        if (!isOriginAuthorized()) return unauthorizedOriginJson()
        val listener = BondhuNotificationListenerService.instance
            ?: return JSONObject().apply {
                put("ok", false)
                put("errorCode", "NOTIFICATION_SERVICE_DISABLED")
                put("message", "Notification Listener অনুমতি চালু করা নেই।")
            }.toString()
        return listener.readSafeNotifications(confirmed).toString()
    }

    @JavascriptInterface
    fun findDeviceFiles(query: String): String {
        if (!isOriginAuthorized()) return unauthorizedOriginJson()
        return intentExecutor.findDeviceFiles(query).toString()
    }

    @JavascriptInterface
    fun openSystemSettings(settingType: String): String {
        if (!isOriginAuthorized()) return unauthorizedOriginJson()
        return intentExecutor.openSystemSettings(settingType).toString()
    }

    @JavascriptInterface
    fun performAccessibilityAction(instruction: String, targetText: String, confirmed: Boolean): String {
        if (!isOriginAuthorized()) return unauthorizedOriginJson()
        val service = BondhuAccessibilityService.instance
            ?: return JSONObject().apply {
                put("ok", false)
                put("errorCode", "ACCESSIBILITY_SERVICE_DISABLED")
                put("message", "Bondhu Accessibility Service সেটিংস থেকে চালু করা নেই।")
            }.toString()
        return service.executeUiAction(instruction, targetText, confirmed).toString()
    }

    @JavascriptInterface
    fun setBackgroundWakeWordEnabled(enabled: Boolean, wakeWord: String): String {
        if (!isOriginAuthorized()) return unauthorizedOriginJson()
        if (enabled && !permissionManager.hasMicPermission()) {
            return JSONObject().apply {
                put("ok", false)
                put("errorCode", "MIC_PERMISSION_REQUIRED")
                put("message", "Background Wake Word চালু করতে Microphone অনুমতি প্রয়োজন।")
            }.toString()
        }
        val intent = Intent(activity, BondhuForegroundVoiceService::class.java).apply {
            action = if (enabled) BondhuForegroundVoiceService.ACTION_START else BondhuForegroundVoiceService.ACTION_STOP
            putExtra(BondhuForegroundVoiceService.EXTRA_WAKE_WORD, wakeWord)
        }
        activity.runOnUiThread {
            if (enabled) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    activity.startForegroundService(intent)
                } else {
                    activity.startService(intent)
                }
            } else {
                activity.startService(intent)
            }
        }
        return JSONObject().apply {
            put("ok", true)
            put("message", if (enabled) "Background Wake Word চালু হয়েছে।" else "Background Wake Word বন্ধ করা হয়েছে।")
        }.toString()
    }

    @JavascriptInterface
    fun goBack(): String {
        if (!isOriginAuthorized()) return unauthorizedOriginJson()
        activity.runOnUiThread {
            activity.onBackPressedDispatcher.onBackPressed()
        }
        return JSONObject().apply {
            put("ok", true)
            put("message", "পূর্ববর্তী স্ক্রিনে ফিরে যাওয়া হয়েছে (Back Action)।")
        }.toString()
    }

    @JavascriptInterface
    fun goHome(): String {
        if (!isOriginAuthorized()) return unauthorizedOriginJson()
        return try {
            val intent = Intent(Intent.ACTION_MAIN).apply {
                addCategory(Intent.CATEGORY_HOME)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            activity.startActivity(intent)
            JSONObject().apply {
                put("ok", true)
                put("message", "ডিভাইসের Home স্ক্রিনে যাওয়া হয়েছে।")
            }.toString()
        } catch (e: Exception) {
            JSONObject().apply {
                put("ok", false)
                put("errorCode", "GO_HOME_FAILED")
                put("message", "Home স্ক্রিনে যাওয়া সম্ভব হয়নি।")
            }.toString()
        }
    }

    @JavascriptInterface
    fun scroll(direction: String): String {
        if (!isOriginAuthorized()) return unauthorizedOriginJson()
        val service = BondhuAccessibilityService.instance
        if (service != null) {
            return service.executeUiAction("scroll $direction", "", true).toString()
        }
        return JSONObject().apply {
            put("ok", true)
            put("message", "স্ক্রিন $direction স্ক্রল নির্দেশ পাঠানো হয়েছে।")
        }.toString()
    }

    @JavascriptInterface
    fun openKeyboard(): String {
        if (!isOriginAuthorized()) return unauthorizedOriginJson()
        activity.runOnUiThread {
            val imm = activity.getSystemService(Activity.INPUT_METHOD_SERVICE) as? android.view.inputmethod.InputMethodManager
            val currentFocus = activity.currentFocus ?: activity.window.decorView
            imm?.showSoftInput(currentFocus, android.view.inputmethod.InputMethodManager.SHOW_IMPLICIT)
        }
        return JSONObject().apply {
            put("ok", true)
            put("message", "কিবোর্ড ও ইনপুট ফিল্ড সক্রিয় করা হয়েছে।")
        }.toString()
    }

    @JavascriptInterface
    fun typeText(text: String): String {
        if (!isOriginAuthorized()) return unauthorizedOriginJson()
        // Strict security: Never type passwords, PINs, OTPs, or confidential credentials
        val lower = text.lowercase()
        if (lower.contains("password") || lower.contains("pin") || lower.contains("otp") || lower.contains("cvv") || lower.contains("পাসওয়ার্ড")) {
            return JSONObject().apply {
                put("ok", false)
                put("errorCode", "SENSITIVE_DATA_BLOCKED")
                put("message", "নিরাপত্তা নীতি অনুযায়ী পাসওয়ার্ড, পিন বা গোপন কোড টাইপ করা নিষিদ্ধ।")
            }.toString()
        }
        val service = BondhuAccessibilityService.instance
        if (service != null) {
            return service.executeUiAction("type $text", "", true).toString()
        }
        return JSONObject().apply {
            put("ok", false)
            put("errorCode", "ACCESSIBILITY_REQUIRED")
            put("message", "অন্য অ্যাপের টেক্সটবক্সে লিখতে Android Accessibility সার্ভিস চালু করা প্রয়োজন।")
        }.toString()
    }

    @JavascriptInterface
    fun openCamera(): String {
        return openNativeCamera()
    }

    @JavascriptInterface
    fun openFilePicker(mediaType: String): String {
        return requestMediaPicker(mediaType)
    }

    @JavascriptInterface
    fun openDialer(contactOrNumber: String): String {
        return makePhoneCall(contactOrNumber)
    }

    @JavascriptInterface
    fun openSms(contactOrNumber: String, textBody: String, confirmed: Boolean): String {
        return prepareOrSendSms(contactOrNumber, textBody, confirmed)
    }

    @JavascriptInterface
    fun share(text: String, title: String, url: String): String {
        return shareContent(text, title, url)
    }

    @JavascriptInterface
    fun openRecentApps(): String {
        if (!isOriginAuthorized()) return unauthorizedOriginJson()
        val service = BondhuAccessibilityService.instance
        if (service != null) {
            val ok = service.performGlobal(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_RECENTS)
            return JSONObject().apply {
                put("ok", ok)
                put("message", if (ok) "রিসেন্ট অ্যাপস স্ক্রিন খোলা হয়েছে।" else "রিসেন্ট অ্যাপস খোলা যায়নি।")
            }.toString()
        }
        return JSONObject().apply {
            put("ok", false)
            put("errorCode", "ACCESSIBILITY_REQUIRED")
            put("message", "রিসেন্ট অ্যাপস স্ক্রিন খুলতে Android Accessibility Service চালু করা প্রয়োজন।")
        }.toString()
    }

    @JavascriptInterface
    fun openPowerMenu(): String {
        if (!isOriginAuthorized()) return unauthorizedOriginJson()
        val service = BondhuAccessibilityService.instance
        if (service != null) {
            val ok = service.performGlobal(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_POWER_DIALOG)
            return JSONObject().apply {
                put("ok", ok)
                put("message", if (ok) "অ্যান্ড্রয়েডের অফিশিয়াল পাওয়ার ডায়ালগ খোলা হয়েছে (শাটডাউন বা রিস্টার্ট করুন)।" else "পাওয়ার মেনু খোলা যায়নি।")
            }.toString()
        }
        return JSONObject().apply {
            put("ok", false)
            put("errorCode", "ACCESSIBILITY_REQUIRED")
            put("message", "অ্যান্ড্রয়েড নিরাপত্তা নীতি অনুসারে সাধারণ অ্যাপ সরাসরি ডিভাইস বন্ধ করতে পারে না। সিস্টেম পাওয়ার মেনু আনতে Android Accessibility Service চালু করুন।")
        }.toString()
    }

    @JavascriptInterface
    fun tapClick(targetText: String): String {
        if (!isOriginAuthorized()) return unauthorizedOriginJson()
        val service = BondhuAccessibilityService.instance
        if (service != null) {
            return service.executeUiAction("click $targetText", targetText, true).toString()
        }
        return JSONObject().apply {
            put("ok", false)
            put("errorCode", "ACCESSIBILITY_REQUIRED")
            put("message", "স্ক্রিনের উপাদান ট্যাপ/ক্লিক করতে Android Accessibility Service চালু করুন।")
        }.toString()
    }

    @JavascriptInterface
    fun adjustVolume(settingType: String): String {
        if (!isOriginAuthorized()) return unauthorizedOriginJson()
        return intentExecutor.openSystemSettings("sound").toString()
    }

    @JavascriptInterface
    fun getDeviceStatusJson(): String {
        if (!isOriginAuthorized()) return unauthorizedOriginJson()
        return try {
            // 1. Battery Status
            val ifilter = IntentFilter(Intent.ACTION_BATTERY_CHANGED)
            val bStatus: Intent? = activity.registerReceiver(null, ifilter)
            val level = bStatus?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
            val scale = bStatus?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
            val batteryPct = if (level >= 0 && scale > 0) (level * 100 / scale.toFloat()).toInt() else -1
            val bStat = bStatus?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
            val isCharging = bStat == BatteryManager.BATTERY_STATUS_CHARGING || bStat == BatteryManager.BATTERY_STATUS_FULL

            // 2. Uptime
            val uptimeMs = SystemClock.elapsedRealtime()
            val totalSeconds = uptimeMs / 1000
            val hours = totalSeconds / 3600
            val minutes = (totalSeconds % 3600) / 60
            val uptimeText = if (hours > 0) "${hours} ঘণ্টা ${minutes} মিনিট" else "${minutes} মিনিট"

            // 3. Network
            val cm = activity.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
            val netInfo = cm?.activeNetworkInfo
            val isOnline = netInfo?.isConnectedOrConnecting == true
            val netType = netInfo?.typeName ?: if (isOnline) "Online" else "Offline"

            // 4. Active Window Package
            val activePackage = BondhuAccessibilityService.instance?.getActivePackageName() ?: activity.packageName

            val details = JSONObject().apply {
                put("batteryPercent", batteryPct)
                put("isCharging", isCharging)
                put("uptimeHours", hours)
                put("uptimeMinutes", minutes)
                put("uptimeFormatted", uptimeText)
                put("isOnline", isOnline)
                put("networkType", netType)
                put("deviceModel", "${Build.MANUFACTURER} ${Build.MODEL}")
                put("androidVersion", Build.VERSION.RELEASE)
                put("activePackage", activePackage)
            }

            val batteryMsg = if (batteryPct >= 0) "$batteryPct% (${if (isCharging) "চার্জ হচ্ছে" else "ব্যাটারিতে চলছে"})" else "অনুপলব্ধ"
            val message = "ফোনের বর্তমান অবস্থা:\n• ব্যাটারি: $batteryMsg\n• নেটওয়ার্ক: $netType (${if (isOnline) "সংযুক্ত" else "অফলাইন"})\n• ফোন চালু আছে: $uptimeText ধরে\n• ডিভাইস: ${Build.MANUFACTURER} ${Build.MODEL} (Android ${Build.VERSION.RELEASE})\n• সক্রিয় অ্যাপ/স্ক্রিন: $activePackage"

            JSONObject().apply {
                put("ok", true)
                put("message", message)
                put("details", details)
            }.toString()
        } catch (e: Exception) {
            JSONObject().apply {
                put("ok", false)
                put("errorCode", "DEVICE_STATUS_ERROR")
                put("message", "ডিভাইসের তথ্য সংগ্রহে ত্রুটি: ${e.message}")
            }.toString()
        }
    }

    @JavascriptInterface
    fun getDeviceOverviewJson(): String {
        if (!isOriginAuthorized()) return unauthorizedOriginJson()
        return try {
            // Storage calculation
            val stat = StatFs(Environment.getDataDirectory().path)
            val bytesAvail = stat.availableBlocksLong * stat.blockSizeLong
            val totalBytes = stat.blockCountLong * stat.blockSizeLong
            val gbAvail = String.format("%.2f", bytesAvail / (1024.0 * 1024.0 * 1024.0))
            val gbTotal = String.format("%.2f", totalBytes / (1024.0 * 1024.0 * 1024.0))

            // Memory
            val actManager = activity.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
            val memInfo = ActivityManager.MemoryInfo()
            actManager?.getMemoryInfo(memInfo)
            val ramAvailGB = String.format("%.2f", memInfo.availMem / (1024.0 * 1024.0 * 1024.0))
            val ramTotalGB = String.format("%.2f", memInfo.totalMem / (1024.0 * 1024.0 * 1024.0))

            val details = JSONObject().apply {
                put("storageAvailableGB", gbAvail)
                put("storageTotalGB", gbTotal)
                put("ramAvailableGB", ramAvailGB)
                put("ramTotalGB", ramTotalGB)
                put("privacyGuaranteed", true)
            }

            val message = "ফোনে অনুমোদিত তথ্যের বিবরণ:\n• ইন্টারনাল স্টোরেজ: $gbAvail GB খালি / $gbTotal GB মোট\n• র‍্যাম (RAM): $ramAvailGB GB খালি / $ramTotalGB GB মোট\n• সিস্টেম নীতি: ছবি, মেসেজ, কল লিস্ট, ফাইল ও নোটিফিকেশন পড়তে সংশ্লিষ্ট Android পারমিশন প্রয়োজন। কোনো প্রকার গোপন নজরদারি নিষিদ্ধ ও সম্পূর্ণ সুরক্ষিত।"

            JSONObject().apply {
                put("ok", true)
                put("message", message)
                put("details", details)
            }.toString()
        } catch (e: Exception) {
            JSONObject().apply {
                put("ok", false)
                put("errorCode", "DEVICE_OVERVIEW_ERROR")
                put("message", "ডিভাইস ওভারভিউ পড়তে ত্রুটি হয়েছে।")
            }.toString()
        }
    }
}
