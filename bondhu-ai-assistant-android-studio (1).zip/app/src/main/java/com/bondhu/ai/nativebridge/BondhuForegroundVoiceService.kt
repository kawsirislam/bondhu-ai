package com.bondhu.ai.nativebridge

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.os.PowerManager
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat

class BondhuForegroundVoiceService : Service() {

    companion object {
        const val CHANNEL_ID = "bondhu_voice_fg_channel"
        const val NOTIF_ID = 4401
        const val ACTION_START = "com.bondhu.ai.START_WAKE_WORD"
        const val ACTION_STOP = "com.bondhu.ai.STOP_WAKE_WORD"
        const val EXTRA_WAKE_WORD = "wake_word"

        @Volatile
        var isServiceRunning = false
            private set
    }

    private var wakeLock: PowerManager.WakeLock? = null
    private var speechRecognizer: SpeechRecognizer? = null
    private var wakeWord = "বন্ধু"
    private var isRestarting = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelfCleanly()
            return START_NOT_STICKY
        }

        wakeWord = intent?.getStringExtra(EXTRA_WAKE_WORD)?.takeIf { it.isNotBlank() } ?: "বন্ধু"

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            stopSelf()
            return START_NOT_STICKY
        }

        val notification = buildForegroundNotification("ব্যাকগ্রাউন্ডে \"$wakeWord\" ওয়েক-ওয়ার্ড সক্রিয় (মাইক্রোফোন চালু)")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIF_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(NOTIF_ID, notification)
        }

        isServiceRunning = true
        acquirePartialWakeLock()
        startWakeWordRecognizer()
        return START_STICKY
    }

    private fun startWakeWordRecognizer() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) return
        speechRecognizer?.destroy()
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(partialResults: Bundle?) {
                    checkWakeMatch(partialResults)
                }
                override fun onResults(results: Bundle?) {
                    checkWakeMatch(results)
                    restartRecognizerSoon()
                }
                override fun onError(error: Int) {
                    restartRecognizerSoon()
                }
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
        }

        val recIntent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "bn-BD")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        }
        speechRecognizer?.startListening(recIntent)
    }

    private fun checkWakeMatch(bundle: Bundle?) {
        val matches = bundle?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION) ?: return
        val hit = matches.any { text ->
            val lower = text.lowercase()
            lower.contains(wakeWord.lowercase()) || lower.contains("bondhu") || lower.contains("বন্ধু")
        }
        if (hit) {
            val wakeBroadcast = Intent("com.bondhu.ai.WAKE_WORD_DETECTED").setPackage(packageName)
            sendBroadcast(wakeBroadcast)
        }
    }

    private fun restartRecognizerSoon() {
        if (!isServiceRunning || isRestarting) return
        isRestarting = true
        android.os.Handler(mainLooper).postDelayed({
            isRestarting = false
            if (isServiceRunning) startWakeWordRecognizer()
        }, 450)
    }

    private fun acquirePartialWakeLock() {
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        if (wakeLock == null) {
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "BondhuAI::VoiceWakeLock")
        }
        if (wakeLock?.isHeld == false) {
            wakeLock?.acquire(10 * 60 * 1000L)
        }
    }

    private fun stopSelfCleanly() {
        isServiceRunning = false
        speechRecognizer?.destroy()
        speechRecognizer = null
        if (wakeLock?.isHeld == true) {
            wakeLock?.release()
        }
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        isServiceRunning = false
        speechRecognizer?.destroy()
        if (wakeLock?.isHeld == true) {
            wakeLock?.release()
        }
        super.onDestroy()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Bondhu AI Voice Assistant",
                NotificationManager.IMPORTANCE_LOW
            )
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(channel)
        }
    }

    private fun buildForegroundNotification(contentText: String): Notification {
        val stopIntent = Intent(this, BondhuForegroundVoiceService::class.java).apply {
            action = ACTION_STOP
        }
        val stopPending = PendingIntent.getService(
            this,
            1,
            stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Bondhu AI ভয়েস অ্যাসিস্ট্যান্ট সক্রিয়")
            .setContentText(contentText)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true)
            .addAction(android.R.drawable.ic_media_pause, "শোনা বন্ধ করুন", stopPending)
            .build()
    }
}
