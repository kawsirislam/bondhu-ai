package com.bondhu.ai.nativebridge

import android.Manifest
import android.app.Activity
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.ContactsContract
import android.provider.MediaStore
import android.provider.Settings
import android.telephony.SmsManager
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.bondhu.ai.MainActivity
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

class BondhuIntentExecutor(private val context: Context) {

    private val knownAppPackages = mapOf(
        "facebook" to listOf("com.facebook.katana", "com.facebook.lite"),
        "ফেসবুক" to listOf("com.facebook.katana", "com.facebook.lite"),
        "messenger" to listOf("com.facebook.orca"),
        "মেসেঞ্জার" to listOf("com.facebook.orca"),
        "tiktok" to listOf("com.zhiliaoapp.musically", "com.ss.android.ugc.trill", "com.zhiliaoapp.musically.go"),
        "টিকটক" to listOf("com.zhiliaoapp.musically", "com.ss.android.ugc.trill", "com.zhiliaoapp.musically.go"),
        "youtube" to listOf("com.google.android.youtube"),
        "ইউটিউব" to listOf("com.google.android.youtube"),
        "google" to listOf("com.google.android.googlequicksearchbox", "com.google.android.apps.searchlite"),
        "গুগল" to listOf("com.google.android.googlequicksearchbox", "com.google.android.apps.searchlite"),
        "google app" to listOf("com.google.android.googlequicksearchbox", "com.google.android.apps.searchlite"),
        "whatsapp" to listOf("com.whatsapp", "com.whatsapp.w4b"),
        "হোয়াটসঅ্যাপ" to listOf("com.whatsapp", "com.whatsapp.w4b"),
        "instagram" to listOf("com.instagram.android"),
        "ইনস্টাগ্রাম" to listOf("com.instagram.android"),
        "telegram" to listOf("org.telegram.messenger"),
        "টেলিগ্রাম" to listOf("org.telegram.messenger"),
        "chrome" to listOf("com.android.chrome"),
        "ক্রোম" to listOf("com.android.chrome"),
        "files" to listOf("com.google.android.apps.nbu.files"),
        "ফাইল" to listOf("com.google.android.apps.nbu.files"),
        "bkash" to listOf("com.bKash.customerapp"),
        "বিকাশ" to listOf("com.bKash.customerapp"),
        "nagad" to listOf("com.konasl.nagad"),
        "নগদ" to listOf("com.konasl.nagad"),
        "gmail" to listOf("com.google.android.gm"),
        "maps" to listOf("com.google.android.apps.maps")
    )

    fun openApp(appNameOrPackage: String): JSONObject {
        val pm = context.packageManager
        val normalized = appNameOrPackage.trim().lowercase()

        val aliasPackages = knownAppPackages[normalized] ?: listOf(appNameOrPackage.trim())
        for (pkg in aliasPackages) {
            val launch = pm.getLaunchIntentForPackage(pkg)
            if (launch != null) {
                launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(launch)
                return resultJson(true, "$appNameOrPackage চালু করা হয়েছে।", mapOf("packageName" to pkg))
            }
        }

        val mainIntent = Intent(Intent.ACTION_MAIN).apply { addCategory(Intent.CATEGORY_LAUNCHER) }
        val resolveList = pm.queryIntentActivities(mainIntent, PackageManager.MATCH_ALL)
        val match = resolveList.firstOrNull { info ->
            val label = info.loadLabel(pm).toString().lowercase()
            label.contains(normalized) || info.activityInfo.packageName.lowercase().contains(normalized)
        }
        if (match != null) {
            val launch = pm.getLaunchIntentForPackage(match.activityInfo.packageName)
            if (launch != null) {
                launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(launch)
                val appLabel = match.loadLabel(pm).toString()
                return resultJson(true, "$appLabel চালু করা হয়েছে।", mapOf("packageName" to match.activityInfo.packageName))
            }
        }

        return resultJson(false, "আপনার ফোনে \"$appNameOrPackage\" অ্যাপটি খুঁজে পাওয়া যায়নি।", errorCode = "APP_NOT_FOUND")
    }

    fun findInstalledApp(query: String): JSONObject {
        val pm = context.packageManager
        val q = query.trim().lowercase()
        val aliasMatches = knownAppPackages[q]?.toSet() ?: emptySet()
        val mainIntent = Intent(Intent.ACTION_MAIN).apply { addCategory(Intent.CATEGORY_LAUNCHER) }
        val matches = JSONArray()
        val seenPackages = mutableSetOf<String>()

        pm.queryIntentActivities(mainIntent, PackageManager.MATCH_ALL).forEach { info ->
            val pkg = info.activityInfo.packageName
            if (!seenPackages.add(pkg)) return@forEach
            val label = info.loadLabel(pm).toString()
            if (
                q.isEmpty() ||
                aliasMatches.contains(pkg) ||
                label.lowercase().contains(q) ||
                pkg.lowercase().contains(q)
            ) {
                matches.put(JSONObject().apply {
                    put("name", label)
                    put("packageName", pkg)
                })
            }
        }
        return if (matches.length() > 0) {
            resultJson(true, "${matches.length()}টি মিল পাওয়া গেছে।", mapOf("apps" to matches))
        } else {
            resultJson(false, "\"$query\" নামে কোনো ইনস্টল করা অ্যাপ পাওয়া যায়নি।", errorCode = "NO_APPS_FOUND")
        }
    }

    fun makePhoneCall(contactOrNumber: String): JSONObject {
        val number = resolvePhoneNumber(contactOrNumber)
            ?: return resultJson(false, "\"$contactOrNumber\"-এর ফোন নম্বর পাওয়া যায়নি (Contacts অনুমতি যাচাই করুন)।", errorCode = "CONTACT_NOT_FOUND")

        val hasDirectCall = ContextCompat.checkSelfPermission(context, Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED
        val intent = if (hasDirectCall) {
            Intent(Intent.ACTION_CALL, Uri.parse("tel:$number"))
        } else {
            Intent(Intent.ACTION_DIAL, Uri.parse("tel:$number"))
        }
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
        return resultJson(
            true,
            if (hasDirectCall) "$contactOrNumber ($number)-এ কল করা হচ্ছে।" else "$contactOrNumber ($number)-এর জন্য ডায়ালার খোলা হয়েছে।",
            mapOf("phoneNumber" to number, "directCall" to hasDirectCall)
        )
    }

    @Suppress("DEPRECATION")
    fun prepareOrSendSms(contactOrNumber: String, textBody: String, confirmed: Boolean): JSONObject {
        if (!confirmed) {
            return resultJson(false, "SMS পাঠাতে ব্যবহারকারীর নিশ্চিতকরণ প্রয়োজন।", errorCode = "CONFIRMATION_REQUIRED")
        }
        val number = resolvePhoneNumber(contactOrNumber)
            ?: return resultJson(false, "\"$contactOrNumber\"-এর ফোন নম্বর পাওয়া যায়নি।", errorCode = "CONTACT_NOT_FOUND")

        val hasSmsPerm = ContextCompat.checkSelfPermission(context, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED
        return if (hasSmsPerm && textBody.isNotBlank()) {
            val smsManager = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                context.getSystemService(SmsManager::class.java)
            } else {
                SmsManager.getDefault()
            }
            smsManager.sendTextMessage(number, null, textBody, null, null)
            resultJson(true, "$contactOrNumber ($number)-এ SMS পাঠানো হয়েছে।", mapOf("phoneNumber" to number))
        } else {
            val intent = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:$number")).apply {
                putExtra("sms_body", textBody)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            resultJson(true, "$contactOrNumber-এর জন্য SMS স্ক্রিন খোলা হয়েছে।", mapOf("phoneNumber" to number))
        }
    }

    fun openNativeCamera(): JSONObject {
        val hasCameraPerm = ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
        if (!hasCameraPerm) {
            if (context is Activity) {
                BondhuPermissionManager(context).requestSinglePermission("camera")
            }
            return resultJson(
                false,
                "ক্যামেরা চালু করতে Android Camera অনুমতি প্রয়োজন। পারমিশন ডায়ালগ থেকে Allow করুন।",
                errorCode = "CAMERA_PERMISSION_REQUIRED"
            )
        }
        return try {
            val intent = Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            resultJson(true, "ফোনের ক্যামেরা চালু করা হয়েছে।")
        } catch (_: ActivityNotFoundException) {
            resultJson(false, "এই ডিভাইসে ক্যামেরা অ্যাপ খুঁজে পাওয়া যায়নি।", errorCode = "CAMERA_NOT_AVAILABLE")
        } catch (_: SecurityException) {
            resultJson(false, "ক্যামেরা চালানোর জন্য সিস্টেম অনুমতি পাওয়া যায়নি।", errorCode = "CAMERA_PERMISSION_REQUIRED")
        }
    }

    fun shareContent(text: String, title: String, url: String): JSONObject {
        val parts = listOf(text.trim(), url.trim()).filter { it.isNotEmpty() }
        if (parts.isEmpty()) {
            return resultJson(false, "শেয়ার করার মতো কোনো টেক্সট বা লিংক পাওয়া যায়নি।", errorCode = "EMPTY_SHARE_CONTENT")
        }
        val shareBody = parts.joinToString("\n")
        val sendIntent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            if (title.isNotBlank()) {
                putExtra(Intent.EXTRA_SUBJECT, title.trim())
            }
            putExtra(Intent.EXTRA_TEXT, shareBody)
        }
        val chooser = Intent.createChooser(sendIntent, title.ifBlank { "Bondhu AI থেকে শেয়ার করুন" }).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return try {
            context.startActivity(chooser)
            resultJson(true, "Android Share Menu খোলা হয়েছে।")
        } catch (_: Exception) {
            resultJson(false, "Android Share Menu চালু করা যায়নি।", errorCode = "SHARE_FAILED")
        }
    }

    fun createLocalNotification(title: String, body: String, confirmed: Boolean): JSONObject {
        if (!confirmed) {
            return resultJson(false, "নোটিফিকেশন পাঠাতে ব্যবহারকারীর অনুমতি প্রয়োজন।", errorCode = "CONFIRMATION_REQUIRED")
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val granted = ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
            if (!granted) {
                if (context is Activity) {
                    BondhuPermissionManager(context).requestSinglePermission("post_notifications")
                }
                return resultJson(
                    false,
                    "Android নোটিফিকেশন দেখাতে Notification অনুমতি (POST_NOTIFICATIONS) প্রয়োজন।",
                    errorCode = "NOTIFICATION_PERMISSION_REQUIRED"
                )
            }
        }

        val notifTitle = title.ifBlank { "Bondhu AI" }
        val notifBody = body.ifBlank { "নতুন রিমাইন্ডার বা বার্তা।" }
        val channelId = "bondhu_ai_user_alerts"
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "Bondhu AI রিমাইন্ডার ও সতর্কতা",
                NotificationManager.IMPORTANCE_HIGH
            )
            nm.createNotificationChannel(channel)
        }

        val tapIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            context,
            (System.currentTimeMillis() % Int.MAX_VALUE).toInt(),
            tapIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, channelId)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(notifTitle)
            .setContentText(notifBody)
            .setStyle(NotificationCompat.BigTextStyle().bigText(notifBody))
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setContentIntent(pendingIntent)
            .build()

        val notifId = (System.currentTimeMillis() and 0x7FFFFFFF).toInt()
        nm.notify(notifId, notification)

        return resultJson(true, "ফোনে নোটিফিকেশন পাঠানো হয়েছে: $notifTitle", mapOf("notificationId" to notifId))
    }

    fun openSystemSettings(settingType: String): JSONObject {
        val action = when (settingType.trim().lowercase()) {
            "wifi", "wi-fi" -> Settings.ACTION_WIFI_SETTINGS
            "bluetooth" -> Settings.ACTION_BLUETOOTH_SETTINGS
            "location", "gps" -> Settings.ACTION_LOCATION_SOURCE_SETTINGS
            "sound", "volume" -> Settings.ACTION_SOUND_SETTINGS
            "display", "brightness" -> Settings.ACTION_DISPLAY_SETTINGS
            "battery" -> Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS
            "accessibility" -> Settings.ACTION_ACCESSIBILITY_SETTINGS
            else -> Settings.ACTION_SETTINGS
        }
        val intent = Intent(action).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }
        context.startActivity(intent)
        return resultJson(true, "${settingType.ifBlank { "System" }} সেটিংস খোলা হয়েছে।")
    }

    fun findDeviceFiles(query: String): JSONObject {
        val q = query.trim().lowercase()
        val found = JSONArray()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            try {
                val projection = arrayOf(
                    MediaStore.Downloads.DISPLAY_NAME,
                    MediaStore.Downloads.SIZE
                )
                context.contentResolver.query(
                    MediaStore.Downloads.EXTERNAL_CONTENT_URI,
                    projection,
                    null,
                    null,
                    "${MediaStore.Downloads.DATE_MODIFIED} DESC"
                )?.use { cursor ->
                    val nameIdx = cursor.getColumnIndexOrThrow(MediaStore.Downloads.DISPLAY_NAME)
                    val sizeIdx = cursor.getColumnIndexOrThrow(MediaStore.Downloads.SIZE)
                    while (cursor.moveToNext() && found.length() < 30) {
                        val name = cursor.getString(nameIdx) ?: continue
                        if (q.isEmpty() || name.lowercase().contains(q)) {
                            found.put(JSONObject().apply {
                                put("name", name)
                                put("sizeBytes", cursor.getLong(sizeIdx))
                            })
                        }
                    }
                }
            } catch (_: Exception) {}
        }

        if (found.length() == 0) {
            val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
            if (downloadsDir?.exists() == true) {
                downloadsDir.listFiles()?.take(50)?.forEach { file: File ->
                    if (q.isEmpty() || file.name.lowercase().contains(q)) {
                        found.put(JSONObject().apply {
                            put("name", file.name)
                            put("path", file.absolutePath)
                            put("sizeBytes", file.length())
                        })
                    }
                }
            }
        }

        return if (found.length() > 0) {
            resultJson(true, "${found.length()}টি ফাইল পাওয়া গেছে।", mapOf("files" to found))
        } else {
            resultJson(false, "\"$query\" নামের কোনো ফাইল Downloads-এ পাওয়া যায়নি।", errorCode = "FILES_NOT_FOUND")
        }
    }

    private fun resolvePhoneNumber(contactOrNumber: String): String? {
        val digitsOnly = contactOrNumber.replace(Regex("[^\\d+]"), "")
        if (digitsOnly.length >= 4) return digitsOnly

        if (ContextCompat.checkSelfPermission(context, Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            return null
        }

        val cursor = context.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                ContactsContract.CommonDataKinds.Phone.NUMBER
            ),
            "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?",
            arrayOf("%${contactOrNumber.trim()}%"),
            null
        )
        cursor?.use {
            if (it.moveToFirst()) {
                return it.getString(it.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.NUMBER))
            }
        }
        return null
    }

    private fun resultJson(
        ok: Boolean,
        message: String,
        details: Map<String, Any>? = null,
        errorCode: String? = null
    ): JSONObject {
        return JSONObject().apply {
            put("ok", ok)
            put("message", message)
            if (errorCode != null) put("errorCode", errorCode)
            if (details != null) {
                put("details", JSONObject(details))
            }
        }
    }
}
