# Keep Bondhu Android WebView JavascriptInterface methods intact in Release APK builds
-keepclassmembers class com.bondhu.ai.nativebridge.BondhuWebViewBridge {
    @android.webkit.JavascriptInterface <methods>;
}
-keepattributes JavascriptInterface
-keepattributes *Annotation*
